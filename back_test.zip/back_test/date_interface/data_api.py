from back_test.date_interface import jq_data




data_api_dict = {
    "jq":jq_data
}

UserDataApi = data_api_dict['jq']